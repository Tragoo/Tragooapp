import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';

import '../screens/Main.dart';
/*import 'package:tragoo_admin_pannel/Screens/dashBoard_Screen.dart';
import 'package:tragoo_admin_pannel/Screens/orders_screen.dart';*/

class NotificationRoute extends StatefulWidget {
  const NotificationRoute({super.key});

  @override
  _NotificationRouteState createState() => _NotificationRouteState();
}

class _NotificationRouteState extends State<NotificationRoute> {
  final GlobalKey<NavigatorState> _navigatorKey = GlobalKey<NavigatorState>();

  void _doSomethingOnStart() async {
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      _navigatorKey.currentState!.pushNamed('/notificationRoute');
      orderid = getorderid(message.data).toString();
    });
  }

  String getorderid(Map<String, dynamic> message) {
    String orderid = message['order_id'];
    return orderid;
  }

  @override
  void initState() {
    _doSomethingOnStart();
    // TODO: implement initState
    super.initState();
  }

  String orderid = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Navigator(
        key: _navigatorKey,
        initialRoute: '/',
        onGenerateRoute: (RouteSettings settings) {
          switch (settings.name) {
            case '/':
              return MaterialPageRoute(builder: (_) => const MyNewHomePage());
            case '/notificationRoute':
              return MaterialPageRoute(
                  builder: (_) => MyNewHomePage());   //yahan wo apge bhe aa saktay hain jahan navigate karna ha
            default:
              return null;
          }
        },
      ),
    );
  }
}
