import 'package:flutter/material.dart';

 Color  kPrimaryClr = Colors.blue;


class AppColors {
  static  final  kPrimaryClr = Colors.blue;
  static const kBlackClr = Colors.black87;
  static final kGreyClr = Colors.grey.shade400;
  static const kWhiteClr = Colors.white;
  static final kGreyCommentClr = Colors.grey.shade100;
  static final kGreyInactive = Colors.grey.shade200;
  static final kGreyQuestionClr = Colors.grey.shade500;
  static const kRedClr = Colors.red;
  static final kGreyBtnClr = Colors.grey[600];
  static final kGreyIconClr = Colors.grey.shade400;

}
